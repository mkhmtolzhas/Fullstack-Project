from fastapi import APIRouter, Depends
from auth.database import get_async_session
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi_users.db import SQLAlchemyBaseUserTable, SQLAlchemyUserDatabase
from get_tour.models import tour



router = APIRouter(
    prefix="/tours",
    tags=["Tour"]
)

@router.get("/")
async def get_user_tour(tour_name: str, session: AsyncSession = Depends(get_async_session)):
    try:
        query = select(tour).where(tour.c.tour_name == tour_name)
        print(query)
        result = await session.execute(query)
        
        return result.scalar()
    except Exception as e:
        print(e)