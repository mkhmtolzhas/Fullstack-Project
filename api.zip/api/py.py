from fastapi import FastAPI, Depends
from fastapi_users import FastAPIUsers


from auth.database import User
from auth.auth import auth_backend
from auth.manager import get_user_manager
from auth.schemas import UserRead, UserCreate


from get_tour.router import router as router_tour

app = FastAPI()

fastapi_users = FastAPIUsers[User, int](
    get_user_manager,
    [auth_backend],
)

current_user = fastapi_users.current_user()
print(type(current_user))
print(current_user)